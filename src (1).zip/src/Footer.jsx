import React, {Component } from "react";
import './addDelete.css';


class Footer extends Component{
constructor(props){
    super(props);
}
render(){
    return(
        <div className="footershop">
          
          <p>Shoping@2019</p>
                
           

        </div>
    )
}

}


export default Footer;